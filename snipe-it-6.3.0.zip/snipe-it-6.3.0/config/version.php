<?php
return array (
  'app_version' => 'v6.3.0',
  'full_app_version' => 'v6.3.0 - build 12490-g9136415bb',
  'build_version' => '12490',
  'prerelease_version' => '',
  'hash_version' => 'g9136415bb',
  'full_hash' => 'v6.3.0-729-g9136415bb',
  'branch' => 'master',
);